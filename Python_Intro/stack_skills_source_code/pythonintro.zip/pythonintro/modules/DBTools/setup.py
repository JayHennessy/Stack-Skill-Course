from setuptools import setup
setup(
 name='DBTools',
 version='1.1',
 description='Managing DB Connections',
 author='Loonycorn',
 author_email='anonymous@loonycorn.com',
 url='loonycorn.com',
 py_modules=['DBTools'],
)
