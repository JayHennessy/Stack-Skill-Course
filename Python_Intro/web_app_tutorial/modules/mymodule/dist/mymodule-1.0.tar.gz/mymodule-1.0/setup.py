from setuptools import setup
setup(
 name='mymodule',
 version='1.0',
 description='My very first Python Module!',
 author='Loonycorn',
 author_email='anonymous@loonycorn.com',
 url='loonycorn.com',
 py_modules=['mymodule'],
)
